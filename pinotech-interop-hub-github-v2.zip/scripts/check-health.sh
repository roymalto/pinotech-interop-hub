#!/bin/bash
echo "Checking service health..."
docker compose ps
